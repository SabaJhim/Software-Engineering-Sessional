import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bank B = new Bank();
        Scanner sc = new Scanner(System.in);

        while (sc.hasNextLine()) {
            String Line = sc.nextLine();
            String[] Command = Line.split(" ");

            //Case starts from here
            if (Command[0].equals("Create")) {
                System.out.println(Command[1] + " " + Command[2] + " " + Command[3]);
                double deposit = Double.parseDouble(Command[3]);
                B.CreateAc(Command[1],Command[2],deposit);
            }
            else if(Command[0].equals("Deposit")){
                System.out.println("Inside Deposit");
                double deposit=Double.parseDouble(Command[1]);
                B.deposit(deposit);

            }
            else if(Command[0].equals("Withdraw")){
                System.out.println("Inside Withdraw");
                double withdraw=Double.parseDouble(Command[1]);
                System.out.println(Command[0]+" "+Command[1]+" "+withdraw);
                B.withdraw(withdraw);
            }
            else if(Command[0].equals("Query")){
                System.out.println("inside Query");
                B.queryAccount();
            }
            else if(Command[0].equals("Request")){
                System.out.println("Inside Loan Request");
                double loan=Double.parseDouble(Command[1]);
                B.requestLoan(loan);
            }
            else if (Command[0].equals("Close")) {
                B.closeTransaction();
            }
            else if(Command[0].equals("Open")){
                B.openTransaction(Command[1]);
            }
            else if(Command[0].equals("Approve")){
                B.ApproveLoanHandlerEmployee();
            }
            else if(Command[0].equals("Change")){
                double rate=Double.parseDouble(Command[2]);
                B.ChangeInterestRateHandler(Command[1],rate);
            }
            else if(Command[0].equals("Lookup")){
                B.LookupEmployee(Command[1]);
            }
            else if(Command[0].equals("See")){
                B.SeeFundEmployee();
            }
            else if(Command[0].equals("Inc")){
                B.timeIncrement();
            }
            else {
                System.out.println("invalid command");
            }
        }

    }
}