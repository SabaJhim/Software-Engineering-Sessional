import java.util.ArrayList;
import java.util.List;

public class Bank {
    private double totalFund;
    private int clock=0;
    private String CurrentAccount;
    private String CurrentEmployee;
    private String CurrentFunctioningEntity;
    private int numberOfMD=1;
    private int numberOfOfficer=2;
    private int numberOfCashier=5;
    private List<Account> account=new ArrayList<>();
    private List<Employee> employee=new ArrayList<>();

    //Constructor of Bank
    Bank(){
        System.out.println("Bank Created");
        this.totalFund=1000000;
        ManagingDirector M=new ManagingDirector("MD");
        employee.add(M);
        for(int i=1;i<=numberOfOfficer;i++){
          Officer O=new Officer("S"+i) ;
          employee.add(O);
        }
        for(int i=1;i<=numberOfCashier;i++){
            Cashier C=new Cashier("C"+i) ;
            employee.add(C);
        }
        for(int i=0;i<employee.size();i++) {
            System.out.print(employee.get(i).name+",");
        }
        System.out.println("Created");

    }
    //Getter and Setter
    private void SetCurrentAccount(String name){
        CurrentAccount=name;
    }
    private Account getAccount(String name){
        for(int i=0;i<account.size();i++){
            if(account.get(i).getAccName().equals(name)){
                return account.get(i);
            }
        }
        return  null;
    }

    private void SetCurrentlyFunctioning(String name){
        CurrentFunctioningEntity=name;
    }

    private String getEmployeeType(String name){
        Employee temp=getEmployee(name);
        System.out.println(temp.getClass().getSimpleName());
        return temp.getClass().getSimpleName();
    }

    private void SetCurrentEmployee(String name){
        CurrentEmployee=name;
    }

    private Employee getEmployee(String name){
        for(int i=0;i<employee.size();i++){
            if(employee.get(i).name.equals(name)){
                return employee.get(i);
            }
        }
        return  null;
    }
    private void setAccountMaturity(){
        for(int i=0;i<account.size();i++){
            account.get(i).setMaturity();
        }
    }


    //Functions to navigate accounts


    //Create a new account

    //Check if the name already exists or not
    private Boolean existAccount(String name){
        for(int i=0;i<account.size();i++){
            if(account.get(i).getAccName().equals(name)){
                return false;
            }
        }
        return true;

    }

    //Main Create account function
    void CreateAc(String name,String type,double deposit){
        Boolean exist=existAccount(name);
        if(exist) {
            if (type.equals("Savings")) {
                Savings sAC = new Savings(name, deposit);
                account.add(sAC);
                System.out.println("Savings account for "+name+" Created; initial balance "+deposit);
                totalFund=totalFund+deposit;
                SetCurrentAccount(name);
                SetCurrentlyFunctioning("Account");

            } else if (type.equals("Student")) {
                Student sAC = new Student(name, deposit);
                account.add(sAC);
                System.out.println("Student account for "+name+" Created; initial balance "+deposit);
                totalFund=totalFund+deposit;
                SetCurrentAccount(name);
                SetCurrentlyFunctioning("Account");

            } else if (type.equals("Fixed Deposit")) {
                if(deposit>=1000000) {
                    fixedDeposit sAC = new fixedDeposit(name, deposit);
                    account.add(sAC);
                    System.out.println("Fixed Deposit account for " + name + " Created; initial balance " + deposit);
                    totalFund=totalFund+deposit;
                    SetCurrentAccount(name);
                    SetCurrentlyFunctioning("Account");
                }
                else{
                    System.out.println("Not sufficient deposit");
                }

            }
        }
        else {
            System.out.println("Account Already exists");
        }

    }

    //Deposit into an account
    void deposit(double amount){
        Account temp=getAccount(CurrentAccount);
        temp.deposit(amount);
        totalFund=totalFund+amount;
    }

    //Withdraw money from an account
    void withdraw(double withdraw){
        Account temp=getAccount(CurrentAccount);
        temp.withdraw(withdraw);
        totalFund=totalFund-withdraw;
    }

    //Request loan for an account

    //Check whether bank is able to give that loan

    private Boolean checkLoanAvailibility(double amount){
        if(amount>totalFund){
            return false;
        }
        else{ return true;}
    }

    //Main request loan function
    void requestLoan(double amount){
        Boolean checkAvailibility=checkLoanAvailibility(amount);
        if(checkAvailibility){
            Account temp=getAccount(CurrentAccount);
            temp.requestLoan(amount);
        }
        else{
            System.out.println("Bank can not provide this much loan");
        }
    }

    //Query an account details for account holder

    void queryAccount(){
        Account temp=getAccount(CurrentAccount);
        temp.queryDeposit();
    }


    //Common Functionalities for employee and account

    //Time increment function


    //Adjusts the yearly interest increment and decrement of an account

    private void AdjustYearlyChange(){
        for(int i=0;i<account.size();i++){
            account.get(i).adjustTotalBalance();
            //totalFund=totalFund+deducted;
        }
    }
    //Main time increment function
    void timeIncrement(){
        clock=clock+1;
        setAccountMaturity();
        AdjustYearlyChange();
        System.out.println("1 year passed");

    }
//Open and Close transaction

//Which type of transaction is going to happen
    private String FindTypeOfTransaction(String name){
        for(int i=0;i<account.size();i++){
            if(name.equals(account.get(i).getAccName())){
                return "Account";
            }
        }
        for(int i=0;i<employee.size();i++){
            if(name.equals(employee.get(i).name)){
                return "Employee";
            }
        }
        return null;
    }
    //Checks whether any loan for any account is pending
    private Boolean checkPendingLoan(){
        for(int i=0;i<account.size();i++){
            if(account.get(i).getRequestedLoan()>0){
                return true;
            }
        }
        return false;
    }
    //Show loan approval status when an employee logged in
    private void showApprovalStatus(){
        Boolean checkLoan = checkPendingLoan();
        if (checkLoan) {

            System.out.println("there are loan approvals pending");
        } else {
            System.out.println("No loan approvals pending");
        }

    }
    //Main open transaction function
void openTransaction(String name){
    String type=FindTypeOfTransaction(name);
    if(type.equals("Account")){
        SetCurrentlyFunctioning("Account");
        SetCurrentAccount(name);
        System.out.println("Welcome Back "+name);
    }
    else if(type.equals("Employee")){
        SetCurrentlyFunctioning("Employee");
        SetCurrentEmployee(name);
        System.out.println(("Current employee "+CurrentFunctioningEntity+" "+CurrentEmployee));
        System.out.println(name+" active");
        String temp=getEmployeeType(name);
        if(!(temp.equals("Cashier"))) {
            showApprovalStatus();
        }
    }
}

//Main Close transaction function

    void closeTransaction(){
        if(CurrentFunctioningEntity.equals("Account")){
            System.out.println("Transaction closed for "+getAccount(CurrentAccount).getAccName());
        }
        else if(CurrentFunctioningEntity.equals("Employee")){
            System.out.println("Operations for "+getEmployee(CurrentEmployee).name+" closed");
        }
        SetCurrentAccount(" ");
        SetCurrentEmployee(" ");
        SetCurrentlyFunctioning(" ");
    }


//Functions to navigate employee

    //Look up an account details for employee
    void LookupEmployee(String AccName){
        Employee temp=getEmployee(CurrentEmployee);
        Account Acc=getAccount(AccName);
        temp.Lookup(Acc);
    }

    //Approve loan for an employee

    void ApproveLoanEmployee(String AccName){
        Employee temp=getEmployee(CurrentEmployee);
        Account Acc=getAccount(AccName);
        if(checkLoanAvailibility(Acc.getRequestedLoan())) {
            temp.ApproveLoan(Acc);
        }
        else{
            System.out.println("Loan request for "+Acc.getAccName()+" denied");
        }
    }
    void ApproveLoanHandlerEmployee(){
        for(int i=0;i<account.size();i++){
            if(account.get(i).getRequestedLoan()>0){
                ApproveLoanEmployee(account.get(i).getAccName());
            }
        }
    }

    //Change interest rate for employee

        void ChangeInterestRateHandler(String type,double rate){
        Employee temp=getEmployee(CurrentEmployee);
        if(temp.getClass().getSimpleName().equals("ManagingDirector")){
            System.out.println("Into managing director");
            ManagingDirector.ChangeInterestRate(type,rate);
        }
        else{
            Employee.ChangeInterestRate(type,rate);
        }
    }


//See internal fund for employee
    void SeeFundEmployee(){
        Employee temp=getEmployee(CurrentEmployee);
        temp.SeeInternalFund(totalFund);
    }



}
