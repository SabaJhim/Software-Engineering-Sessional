abstract class Employee {
    String name;


    void Lookup(Account currentAccount){
      System.out.println(currentAccount.getAccName()+"'s current balance is "+currentAccount.getTotalBalance());
    }
    void SeeInternalFund(double internalFund){
        System.out.println("You don't have the permission for this operation");
    }
    void ApproveLoan(Account Acc){
        System.out.println("You don't have the permission for this operation");

    }
     static void ChangeInterestRate(String name,double rate){
        System.out.println("You don't have the permission for this operation");
    }

}

class ManagingDirector extends Employee{
    ManagingDirector(String name){
        this.name=name;
    }
    void ApproveLoan(Account Acc){
        Acc.loanApproved();
        System.out.println("Loan for "+Acc.getAccName()+" approved");
    }
    static void ChangeInterestRate(String type,double rate){
        if (type.equals("Savings")){
            Savings.setInterest_rate(rate);
            System.out.println(type+" type account's interest rate changed into "+rate);
        }
        else if(type.equals("Student")){
            Student.setInterest_rate(rate);
            System.out.println(type+" type account's interest rate changed into "+rate);
        }
        else if(type.equals("Fixed Deposit")){
            fixedDeposit.setInterest_rate(rate);
            System.out.println(type+" type account's interest rate changed into "+rate);
        }
    }
    void SeeInternalFund(double internalFund){
        System.out.println("Internal Fund is "+internalFund);
    }
}

class Officer extends Employee{
    Officer(String name){
        this.name=name;
    }
    void ApproveLoan(Account Acc){
        Acc.loanApproved();
        System.out.println("Loan for "+Acc.getAccName()+" approved");
    }

}
class Cashier extends Employee{
    Cashier(String name){
        this.name=name;
    }

}