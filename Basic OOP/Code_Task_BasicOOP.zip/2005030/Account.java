 abstract class Account {
    private String AccName;
    private double totalBalance;
    private int maturity=0;
    private double requestedLoan=0;
    private double grantedLoan=0;

    //Getter and Setter
     String getAccName(){
         return AccName;
     }
     void setAccName(String name){
         AccName=name;
     }
     double getTotalBalance(){
         return totalBalance;
     }
     void setTotalBalance(double balance){
         totalBalance=balance;
     }
     void setMaturity(){
         maturity=maturity+1;
     }
     int getMaturity(){
         return maturity;
     }

      double getRequestedLoan() {
         return requestedLoan;
     }

     public void setRequestedLoan(double requestedLoan) {
         this.requestedLoan = requestedLoan;
     }

     double getGrantedLoan() {
         return grantedLoan;
     }
     void setGrantedLoan(double grantedLoan){
         this.grantedLoan=grantedLoan;

     }

     //Abstract methods for different types of account

     abstract void deposit(double deposit);
    abstract void withdraw(double withdraw);
    abstract void requestLoan(double amount);
    abstract void adjustTotalBalance();


    //Common Functions for all type of account

   //Query the current state of account
    void queryDeposit(){

        System.out.println("Current Balance "+totalBalance+" .Loan "+grantedLoan);
    }
    //Checks whether amount is sufficient for withdrawal
     Boolean confirmWithdrawal(double withdraw){
         if(totalBalance-withdraw<0){
             return false;
         }
         else return true;
     }
     //Reflects necessary changes after loan approval
     void loanApproved(){
        totalBalance=totalBalance+requestedLoan;
        grantedLoan=requestedLoan;
        requestedLoan=0;

     }
     //Returns the amount of loan deduction interest
     double getloanDeductionAmount(){
        return 0.1*grantedLoan;
     }

}

class Savings extends Account{
    static double interest_rate;
    //Constructor
    Savings(String AccName,double deposit){
        setAccName(AccName);
        setTotalBalance(deposit);
        this.interest_rate=10;

    }
    //Set Interest rate for a particular account
    public static void setInterest_rate(double rate){
        interest_rate=rate;
    }

    //Deposit function
     public void deposit(double deposit){
        setTotalBalance(getTotalBalance()+deposit);
        System.out.println(deposit+"$ deposited; "+"Current balance "+getTotalBalance());
    }
    //Withdraw function

    public void withdraw(double withdraw){
        Boolean confirmation=confirmWithdrawal(withdraw);
        if(confirmation==true){
            if(getTotalBalance()-withdraw>=1000){
                setTotalBalance(getTotalBalance()-withdraw);
                System.out.println(withdraw+"$ withdrawn. Current balance "+getTotalBalance());
            }
            else{
                System.out.println("Invalid operation.Current balance "+getTotalBalance());
            }
        }
        else{
            System.out.println("Invalid operation.Current balance "+getTotalBalance());
        }
    }

    //Request loan function
    public void requestLoan(double amount){
        if(amount<=10000){
            setRequestedLoan(amount);
            System.out.println("Loan request successful.Sent for approval");
        }
        else{
            System.out.println("Loan request is not successful.");
        }
    }
    //Balance adjust function
    public void adjustTotalBalance(){
        double deductionloan=getloanDeductionAmount();
        setTotalBalance(getTotalBalance()+getTotalBalance()*(interest_rate/100));
        setTotalBalance(getTotalBalance()-500);
        setTotalBalance(getTotalBalance()-deductionloan);
    }

}

class Student extends Account{
    static double interest_rate;
    Student(String AccName,double deposit){
        setAccName(AccName);
        setTotalBalance(deposit);
        this.interest_rate=5;
    }
    static void setInterest_rate(double rate){
        interest_rate=rate;
    }
    public void deposit(double deposit){
        setTotalBalance(getTotalBalance()+deposit);
        System.out.println(deposit+"$ deposited; "+"Current balance "+getTotalBalance());
    }
    public void withdraw(double withdraw){
        Boolean confirmation=confirmWithdrawal(withdraw);
        if(confirmation==true){
            if(withdraw<=10000){
                setTotalBalance(getTotalBalance()-withdraw);
                System.out.println(withdraw+"$ withdrawn. Current balance "+getTotalBalance());
            }
            else{
                System.out.println("Invalid operation.Current balance "+getTotalBalance());
            }
        }
        else{
            System.out.println("Invalid operation.Current balance "+getTotalBalance());
        }
    }
    public void requestLoan(double amount){
        if(amount<=1000){
            setRequestedLoan(amount);
            System.out.println("Loan request successful.Sent for approval");
        }
        else{
            System.out.println("Loan request is not successful.");
        }
    }
    public void adjustTotalBalance(){
        double deductionloan=getloanDeductionAmount();
        setTotalBalance(getTotalBalance()+getTotalBalance()*(interest_rate/100));
        setTotalBalance(getTotalBalance()-deductionloan);
    }
}

 class fixedDeposit extends Account{
    static double interest_rate;
     fixedDeposit(String AccName,double deposit){
         setAccName(AccName);
         setTotalBalance(deposit);
         this.interest_rate=15;

     }
     public static void setInterest_rate(double rate){
         interest_rate=rate;
     }
     public void deposit(double deposit){
         if(deposit>=50000) {
             setTotalBalance(getTotalBalance()+deposit);
             System.out.println(deposit + "$ deposited; " + "Current balance " + getTotalBalance());
         }
         else{
             System.out.println("Not sufficient amount deposited");
         }
     }
     public void withdraw(double withdraw){
         Boolean confirmation=confirmWithdrawal(withdraw);
         if(confirmation==true){
             if(getMaturity()>0){
                 setTotalBalance(getTotalBalance()-withdraw);
                 System.out.println(withdraw+"$ withdrawn. Current balance "+getTotalBalance());
             }
             else{
                 System.out.println("Invalid operation.Current balance "+getTotalBalance());
             }
         }
         else{
             System.out.println("Invalid operation.Current balance "+getTotalBalance());
         }
     }
     public void requestLoan(double amount){
         if(amount<=100000){
             setRequestedLoan(amount);
             System.out.println("Loan request successful.Sent for approval");
         }
         else{
             System.out.println("Loan request is not successful.");
         }
     }
     public void adjustTotalBalance(){
         double deductionloan=getloanDeductionAmount();
         setTotalBalance(getTotalBalance()+getTotalBalance()*(interest_rate/100));
         setTotalBalance(getTotalBalance()-500);
         setTotalBalance(getTotalBalance()-deductionloan);
     }




 }